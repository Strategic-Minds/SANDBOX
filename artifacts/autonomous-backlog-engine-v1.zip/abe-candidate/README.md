# Autonomous Backlog Engine V1 — Sandbox Candidate

Economic objective: **MAXIMIZE VERIFIED PROFITABLE BACKLOG GENERATED PER CUSTOMER.**

Validated core: opportunity economics, economic attribution, protected-action gates, five-minute heartbeat/hourly lease, recovery state, champion/challenger scoring, CloudBrowser dry-run contract, proposed tenant/RLS schema, promotion and rollback receipts.

Run `npm test` and `npm run check`.

This candidate is non-production. It does not execute migrations, submit bids, message customers, deploy production, change secrets, or make payments.
