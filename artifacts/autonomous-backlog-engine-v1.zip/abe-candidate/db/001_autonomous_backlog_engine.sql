-- AUTONOMOUS BACKLOG ENGINE V1 — PROPOSED MIGRATION ONLY. DO NOT EXECUTE WITHOUT APPROVAL.
-- Tenant-isolated, append-friendly schema for durable backlog generation and recursive improvement.

create extension if not exists pgcrypto;

create table if not exists backlog_customers (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  name text not null,
  trade text not null,
  market text,
  target_gross_margin numeric(7,4),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (tenant_id, id)
);

create table if not exists backlog_opportunities (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  customer_id uuid not null references backlog_customers(id),
  source_id text not null,
  source_type text not null,
  source_url text,
  title text not null,
  trade text,
  market text,
  geography jsonb not null default '{}'::jsonb,
  bid_due_at timestamptz,
  estimated_contract_value numeric(16,2) not null default 0,
  estimated_gross_margin numeric(7,4) not null default 0,
  probability_of_award numeric(7,4) not null default 0,
  expected_gross_profit numeric(16,2) not null default 0,
  value_score numeric(8,2) not null default 0,
  strategic_fit numeric(7,4) not null default 0,
  confidence numeric(7,4) not null default 0,
  estimated_pursuit_cost numeric(16,2) not null default 0,
  risk_factor numeric(7,4) not null default 1,
  status text not null default 'discovered',
  evidence jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, source_type, source_id)
);

create table if not exists backlog_bids (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  customer_id uuid not null references backlog_customers(id),
  opportunity_id uuid not null references backlog_opportunities(id),
  status text not null default 'draft',
  proposed_price numeric(16,2),
  estimated_gross_margin numeric(7,4),
  human_approved_by uuid,
  human_approved_at timestamptz,
  submitted_at timestamptz,
  submission_evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists backlog_outcomes (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  customer_id uuid not null references backlog_customers(id),
  opportunity_id uuid not null references backlog_opportunities(id),
  bid_id uuid references backlog_bids(id),
  result text not null check (result in ('won','lost','withdrawn','unknown')),
  awarded_contract_value numeric(16,2),
  estimated_gross_profit numeric(16,2),
  realized_revenue numeric(16,2),
  realized_cost numeric(16,2),
  realized_gross_profit numeric(16,2),
  outcome_evidence jsonb not null default '{}'::jsonb,
  lesson jsonb not null default '{}'::jsonb,
  recorded_at timestamptz not null default now()
);

create table if not exists improvement_runs (
  id uuid primary key,
  system_id text not null,
  tenant_id uuid,
  project_id text not null,
  customer_id uuid,
  parent_run_id uuid,
  objective text not null,
  current_phase text not null,
  current_step text not null,
  status text not null,
  heartbeat_at timestamptz not null default now(),
  last_verified_step text,
  branch text,
  commit_sha text,
  validation_state text not null default 'pending',
  score_before numeric(8,2),
  score_after numeric(8,2),
  next_action text,
  retry_count integer not null default 0,
  failure_class text,
  artifacts jsonb not null default '[]'::jsonb,
  started_at timestamptz not null default now(),
  completed_at timestamptz
);

create table if not exists execution_leases (
  id uuid primary key default gen_random_uuid(),
  system_id text not null,
  lease_key text not null,
  holder text not null,
  expires_at timestamptz not null,
  released_at timestamptz,
  created_at timestamptz not null default now()
);
create unique index if not exists execution_leases_active_unique
  on execution_leases(system_id, lease_key)
  where released_at is null;

create table if not exists system_scores (
  id uuid primary key default gen_random_uuid(),
  system_id text not null,
  tenant_id uuid,
  score numeric(8,2) not null,
  metrics jsonb not null,
  champion_id uuid,
  evidence jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists improvement_hypotheses (
  id uuid primary key default gen_random_uuid(),
  run_id uuid not null references improvement_runs(id),
  value_score numeric(8,2) not null,
  severity text,
  hypothesis text not null,
  expected_economic_effect jsonb not null default '{}'::jsonb,
  bounded_scope jsonb not null default '{}'::jsonb,
  status text not null default 'proposed',
  created_at timestamptz not null default now()
);

create table if not exists validation_receipts (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  run_id uuid references improvement_runs(id),
  kind text not null,
  status text not null,
  evidence jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists economic_attribution_events (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null,
  customer_id uuid not null,
  opportunity_id uuid,
  bid_id uuid,
  event_type text not null,
  amount numeric(16,2),
  evidence jsonb not null default '{}'::jsonb,
  occurred_at timestamptz not null default now()
);

create table if not exists approval_requests (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  run_id uuid,
  action text not null,
  reason text not null,
  payload_hash text,
  status text not null default 'pending',
  requested_at timestamptz not null default now(),
  decided_at timestamptz,
  decided_by uuid
);

create table if not exists outcome_learnings (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid,
  customer_id uuid,
  trade text,
  market text,
  lesson_type text not null,
  features jsonb not null default '{}'::jsonb,
  result jsonb not null default '{}'::jsonb,
  confidence numeric(7,4),
  source_receipt_id uuid,
  created_at timestamptz not null default now()
);

-- RLS: service-side automation must explicitly set app.tenant_id per request/job.
alter table backlog_customers enable row level security;
alter table backlog_opportunities enable row level security;
alter table backlog_bids enable row level security;
alter table backlog_outcomes enable row level security;
alter table improvement_runs enable row level security;
alter table system_scores enable row level security;
alter table validation_receipts enable row level security;
alter table economic_attribution_events enable row level security;
alter table approval_requests enable row level security;
alter table outcome_learnings enable row level security;

-- Example authenticated tenant policies. Production integration should bind tenant IDs to authoritative memberships.
create policy backlog_customers_tenant on backlog_customers for all using (tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id::text = current_setting('app.tenant_id', true));
create policy backlog_opportunities_tenant on backlog_opportunities for all using (tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id::text = current_setting('app.tenant_id', true));
create policy backlog_bids_tenant on backlog_bids for all using (tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id::text = current_setting('app.tenant_id', true));
create policy backlog_outcomes_tenant on backlog_outcomes for all using (tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id::text = current_setting('app.tenant_id', true));
create policy improvement_runs_tenant on improvement_runs for all using (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true));
create policy system_scores_tenant on system_scores for all using (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true));
create policy validation_receipts_tenant on validation_receipts for all using (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true));
create policy economic_attribution_tenant on economic_attribution_events for all using (tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id::text = current_setting('app.tenant_id', true));
create policy approval_requests_tenant on approval_requests for all using (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true));
create policy outcome_learnings_tenant on outcome_learnings for all using (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true)) with check (tenant_id is null or tenant_id::text = current_setting('app.tenant_id', true));

-- Execution leases intentionally have no public/authenticated policy. Service role only.
-- Rollback: drop newly created tables in reverse dependency order ONLY if operator approves and no real data exists.
