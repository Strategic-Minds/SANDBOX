# Autonomous Backlog Engine V1 Architecture

## Economic north star
MAXIMIZE VERIFIED PROFITABLE BACKLOG GENERATED PER CUSTOMER.

## Control split
- Strategic-Minds/AUTO_BUILDER: authoritative orchestration, governance, specialist routing, durable workflow.
- Strategic-Minds/SANDBOX: implementation/build lane only.
- XTREME-SYSTEMS/cloudbrowser-control: browser execution and independent black-box validation.
- Supabase: tenant-isolated state, outcomes, leases, receipts, learning graph.
- Vercel Workflow/Cron: five-minute validator heartbeat. One hourly lease may start a bounded improvement cycle.

## Runtime loop
5-minute heartbeat -> health/lease/incident/approvals/retry checks -> if hourly due, acquire lease -> OBSERVE -> MEMORY -> BASELINE -> SCORE -> DISCOVER -> RANK -> SELECT -> HYPOTHESIS -> WORK PACKET -> BRANCH BUILD -> TEST -> ADVERSARIAL -> CLOUDBROWSER -> SCORE CHALLENGER -> REPAIR/RETEST -> COMPARE -> CANDIDATE OR REJECT -> RECEIPT -> LEARN -> NEXT ACTION.

## Money loop
Opportunity -> qualify -> evidence -> bid/no-bid -> bid-ready package -> human price approval -> human submission approval -> outcome -> realized margin -> attribution -> learning.

## Non-negotiable gates
The engine never autonomously deploys production, changes secrets, sends customer messages, submits bids, makes payments, accepts contracts, or executes destructive database changes.

## First commercial wedge
V1 should be trade-agnostic in data structures but pilot with specialty concrete / epoxy / polished concrete contractors because access to domain expertise, customers, scopes, products, and estimating feedback shortens the proof loop. This is a pilot choice, not a permanent architectural constraint.
