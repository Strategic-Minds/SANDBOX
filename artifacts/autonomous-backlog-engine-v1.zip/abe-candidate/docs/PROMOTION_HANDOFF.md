# Promotion Handoff

## Sandbox branch
feature/autonomous-backlog-engine-v1

## Promotion targets
- orchestration/contracts/prompts: Strategic-Minds/AUTO_BUILDER
- deployable UI: Strategic-Minds/FRONTEND
- browser adapter contract only: XTREME-SYSTEMS/cloudbrowser-control unless a validated browser defect requires a separate approved branch

## Required before promotion
1. Canonical AUTO_BUILDER GitHub adapter must resolve the source repo.
2. Real Supabase project/schema target must be confirmed.
3. Proposed migration reviewed and explicitly approved before execution.
4. Vercel project must be identified.
5. Preview validation must pass.
6. CloudBrowser black-box validation must pass.
7. No blocking security/regression findings.
8. Operator approval for production-affecting steps.
