# Rollback Plan — Sandbox Candidate

Scope: feature/autonomous-backlog-engine-v1 in Strategic-Minds/SANDBOX only.

Rollback is branch deletion or revert of the candidate commit. No production environment, schema, secret, customer message, or CloudBrowser production runtime is changed by this candidate.

If later promoted:
- Git: revert promotion commit, no force push.
- Supabase: migration requires separately reviewed restore/down strategy before execution.
- Vercel: revert to prior known-good deployment.
- CloudBrowser: no runtime changes are included in this candidate.
